class state:

	def __init__(self, pos):
		self.pos = pos
		self.actionValues = [0.0, 0.0, 0.0]
